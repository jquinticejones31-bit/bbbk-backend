# BigBrosBookkeeping Backend (Google Cloud)

This zip contains the backend services only.

## Included
- Express API for forms, pricing, careers, and payments
- Stripe checkout starter
- PayPal order starter
- Google Cloud deployment notes

## Run locally
1. Copy `.env.example` to `.env`
2. Run `npm install`
3. Run `npm run dev`

Deploy the API to Google Cloud Run.
