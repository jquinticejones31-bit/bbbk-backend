# HR suite integration placeholder

Connect your payroll / HR provider here using provider adapters and webhook handlers.
