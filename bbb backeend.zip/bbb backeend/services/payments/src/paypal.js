const baseUrl = process.env.PAYPAL_ENVIRONMENT === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
export async function getPayPalAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error("PayPal credentials are not configured.");
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const response = await fetch(`${baseUrl}/v1/oauth2/token`, { method: "POST", headers: { Authorization: `Basic ${credentials}`, "Content-Type": "application/x-www-form-urlencoded" }, body: "grant_type=client_credentials" });
  if (!response.ok) throw new Error(`PayPal auth failed: ${response.status}`);
  const data = await response.json();
  return data.access_token;
}
export async function createPayPalOrder({ amount = "299.00", currency = "USD", description = "BigBrosBookkeeping payment" }) {
  const accessToken = await getPayPalAccessToken();
  const response = await fetch(`${baseUrl}/v2/checkout/orders`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ intent: "CAPTURE", purchase_units: [{ description, amount: { currency_code: currency, value: amount } }], application_context: { return_url: `${process.env.FRONTEND_URL || "http://localhost:3002"}?paypal=success`, cancel_url: `${process.env.FRONTEND_URL || "http://localhost:3002"}?paypal=cancelled` } })
  });
  if (!response.ok) throw new Error(`PayPal order creation failed: ${response.status}`);
  return response.json();
}
