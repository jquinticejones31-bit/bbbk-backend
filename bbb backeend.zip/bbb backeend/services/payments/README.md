# Payments service

Included:
- Stripe checkout session starter
- PayPal order creation starter

Before production use, add webhook verification, persistent storage, refunds, and billing reconciliation.
