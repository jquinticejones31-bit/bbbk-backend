# WebSocket / live updates

This starter backend currently exposes a polling `/events` endpoint.

For Google Cloud, you can later replace this with WebSockets on Cloud Run or Pub/Sub based updates.
