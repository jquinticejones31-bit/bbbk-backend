import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import Stripe from "stripe";
import { createPayPalOrder, getPayPalAccessToken } from "../../payments/src/paypal.js";

dotenv.config({ path: new URL("../../../.env", import.meta.url).pathname });
const app = express();
const port = process.env.PORT || 8080;
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
app.use(cors({ origin: true }));
app.use(express.json());
const state = { pricing: [{ name: "Starter", minTx: 0, maxTx: 200, monthlyPrice: 299 }, { name: "Standard", minTx: 201, maxTx: 500, monthlyPrice: 499 }, { name: "Premium", minTx: 501, maxTx: 1000, monthlyPrice: 899 }], events: [] };
function pushEvent(type, payload = {}) { state.events.unshift({ type, ts: Date.now(), ...payload }); state.events = state.events.slice(0, 200); }
app.get("/health", (_req, res) => res.json({ ok: true, service: "bigbrosbookkeeping-api" }));
app.get("/events", (_req, res) => res.json({ ok: true, events: state.events.slice(0, 50) }));
app.get("/pricing", (_req, res) => res.json({ ok: true, tiers: state.pricing }));
app.put("/pricing", (req, res) => { state.pricing = Array.isArray(req.body?.tiers) ? req.body.tiers : state.pricing; pushEvent("pricing.updated", { tiers: state.pricing }); res.json({ ok: true, tiers: state.pricing }); });
app.post("/careers/apply", (req, res) => { pushEvent("career.application.received", { applicant: req.body?.name || "Unknown" }); res.json({ ok: true, application: req.body }); });
app.post("/forms/submit", (req, res) => { pushEvent("form.submitted", { formName: req.body?.formName, companyName: req.body?.companyName }); res.json({ ok: true, form: req.body }); });
app.post("/payments/create-stripe-session", async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ ok: false, error: "Stripe is not configured." });
    const { amount = 29900, currency = "usd", description = "BigBrosBookkeeping payment" } = req.body || {};
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"], mode: "payment",
      line_items: [{ price_data: { currency, product_data: { name: description }, unit_amount: amount }, quantity: 1 }],
      success_url: `${process.env.FRONTEND_URL || "http://localhost:3002"}?payment=success`,
      cancel_url: `${process.env.FRONTEND_URL || "http://localhost:3002"}?payment=cancelled`
    });
    pushEvent("payment.stripe.session_created", { amount, currency, description });
    res.json({ ok: true, id: session.id, url: session.url });
  } catch (error) { res.status(500).json({ ok: false, error: error.message }); }
});
app.post("/payments/create-paypal-order", async (req, res) => {
  try {
    await getPayPalAccessToken();
    const order = await createPayPalOrder(req.body || {});
    const approveUrl = order.links?.find((link) => link.rel === "approve")?.href || null;
    pushEvent("payment.paypal.order_created", { amount: req.body?.amount, currency: req.body?.currency });
    res.json({ ok: true, id: order.id, approveUrl, raw: order });
  } catch (error) { res.status(500).json({ ok: false, error: error.message }); }
});
app.listen(port, () => console.log(`API listening on http://localhost:${port}`));
