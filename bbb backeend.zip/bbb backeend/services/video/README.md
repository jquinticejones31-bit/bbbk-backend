# Video service placeholder

Suggested Google Cloud friendly options: Daily, Vonage, Twilio Video, or LiveKit.
